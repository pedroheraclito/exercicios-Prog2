#include <stdio.h>
#include <stdlib.h>
#include "tarefaimprime.h"
#include <string.h>
#include "tarefamultiplica.h"
#include "tarefasoma.h"

#include "agendatarefas.h"

struct agendatarefas{
    int numelem;
    void **dados;
    int qtdatual;
};

/**
 * @brief Cria uma variável para um tipo genérico que representa uma Agenda de Tarefas
 *
 * @param numElem A quantidade de tarefas que serão armazenadas no agendador
 *
 * @return Um ponteiro para a agenda de tarefas
 */
tAgendaTarefas* CriaAgendaDeTarefas(int numElem){
    tAgendaTarefas *a=(tAgendaTarefas*)calloc(1,sizeof(tAgendaTarefas));

    a->numelem=numElem;
    a->dados=(void**)calloc(numElem,sizeof(void*));

    
    a->qtdatual=0;
    return a;
}

/**
 * @brief Destroi a agenda de tarefas (libera a memória)
 *
 * @param tar - A agenda que terá seu conteúdo liberado/destruído
 */
void DestroiAgendaDeTarefas(tAgendaTarefas* tar){
    for (int i = 0; i < tar->qtdatual; i++)
    {
      free(tar->dados[i]);
    }
    free(tar->dados);
    free(tar);
}

/**
 * @brief Cadastra uma tarefa em um agendador de tarefas
 *
 * @param tar - Pointeiro para a agenda de tarefas
 * @param prioridade - Prioridade de execução da nova tarefa
 * @param tarefa - Ponteiro para nova tarefa a ser executada
 * @param executa - Ponteiro para função (callback) que será chamada quando for a hora de executar a tarefa
 * @param destroi - Ponteiro para função (callback) que será chamada quando for a hora de destruir a tarefa (liberar a memória)
 *
 */
void CadastraTarefaNaAgenda(tAgendaTarefas* tar, int prioridade, void *tarefa, void (*executa)(void*), void (*destroi)(void*) ){
    int sup=prioridade;
    while (tar->dados[sup]==NULL)
    {
       sup++;
    }
    tar->dados[sup]=tarefa;
    executa(tarefa);
    
    
}  

/**
 * @brief Executa as tarefas que estão salvas na agenda de tarefas passada como parâmetro.
 *
 * @param tar Agenda de tarefas
 *
 */
void ExecutarTarefasDaAgenda(tAgendaTarefas* tar){
    
}